#!/bin/bash
docker run -p 80:5000 --name tibame-flask -d 129729052534.dkr.ecr.ap-northeast-1.amazonaws.com/tibami-student16:latest
